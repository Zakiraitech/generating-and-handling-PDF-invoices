import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'file_handle_api.dart';
import 'models/product.dart';

class InvoiceLine {
  final String description;
  final int quantity;
  final double unitPrice;

  const InvoiceLine({
    required this.description,
    required this.quantity,
    required this.unitPrice,
  });

  double get total => quantity * unitPrice;
}

class PdfInvoiceApi {
  /// Builds the PDF document in memory (used by both generate & share).
  static Future<pw.Document> buildDocument({
    required PdfColor color,
    required List<InvoiceLine> items,
    bool discount = false,
    double discountPercent = 20,
  }) async {
    final pdf = pw.Document();

    // ── Load Unicode fonts (required for the ₦ sign) ────────
    final regularFont = pw.Font.ttf(
      await rootBundle.load('assets/fonts/Roboto-Regular.ttf'),
    );
    final boldFont = pw.Font.ttf(
      await rootBundle.load('assets/fonts/Roboto-Bold.ttf'),
    );

    final iconImage =
    (await rootBundle.load('assets/icon.png')).buffer.asUint8List();

    final tableHeaders = <String>[
      'Description',
      'Quantity',
      'Unit Price',
      'VAT',
      'Total',
    ];

    final tableData = items
        .map((line) => <String>[
      line.description,
      line.quantity.toString(),
      '₦ ${formatNaira(line.unitPrice)}',
      '0 %',
      '₦ ${formatNaira(line.total)}',
    ])
        .toList();

    // ── Totals ─────────────────────────────────────────────
    final double netTotal =
    items.fold<double>(0, (sum, l) => sum + l.total);
    final double discountAmount =
    discount ? netTotal * (discountPercent / 100) : 0;
    final double subtotal = netTotal - discountAmount;
    const double vat = 0;
    final double amountDue = subtotal + vat;

    pdf.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(
          base: regularFont,
          bold: boldFont,
          italic: regularFont,
          boldItalic: boldFont,
        ),
        build: (context) {
          return [
            // ── Header ──────────────────────────────────────
            pw.Row(
              children: [
                pw.Image(pw.MemoryImage(iconImage), height: 72, width: 72),
                pw.SizedBox(width: 5 * PdfPageFormat.mm),
                pw.Column(
                  mainAxisSize: pw.MainAxisSize.min,
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      'INVOICE',
                      style: pw.TextStyle(
                        fontSize: 17,
                        fontWeight: pw.FontWeight.bold,
                        color: color,
                      ),
                    ),
                    pw.Text(
                      'Al-Amaz Shop',
                      style: pw.TextStyle(fontSize: 15, color: color),
                    ),
                  ],
                ),
                pw.Spacer(),
                // Right side: only "Dear Customer" now
                pw.Column(
                  mainAxisSize: pw.MainAxisSize.min,
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text(
                      'Dear Customer',
                      style: pw.TextStyle(
                        fontSize: 15.5,
                        fontWeight: pw.FontWeight.bold,
                        color: color,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            pw.SizedBox(height: 5 * PdfPageFormat.mm),
            pw.Divider(),
            pw.SizedBox(height: 5 * PdfPageFormat.mm),

            pw.Text(
              'Dear Customer,\n\n'
                  'Thank you for your order. Please find below the itemised '
                  'list of products purchased.',
              textAlign: pw.TextAlign.justify,
              style: pw.TextStyle(fontSize: 14, color: color),
            ),
            pw.SizedBox(height: 10 * PdfPageFormat.mm),

            // ── Table ───────────────────────────────────────
            pw.Table.fromTextArray(
              headers: tableHeaders,
              data: tableData,
              border: null,
              headerStyle: pw.TextStyle(
                fontWeight: pw.FontWeight.bold,
                color: color,
              ),
              headerDecoration: const pw.BoxDecoration(
                color: PdfColors.grey300,
              ),
              cellStyle: const pw.TextStyle(),
              cellHeight: 26,
              cellAlignments: const {
                0: pw.Alignment.centerLeft,
                1: pw.Alignment.centerRight,
                2: pw.Alignment.centerRight,
                3: pw.Alignment.centerRight,
                4: pw.Alignment.centerRight,
              },
            ),
            pw.Divider(),

            // ── Totals ──────────────────────────────────────
            pw.Container(
              alignment: pw.Alignment.centerRight,
              child: pw.Row(
                children: [
                  pw.Spacer(flex: 6),
                  pw.Expanded(
                    flex: 4,
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Row(
                          children: [
                            pw.Expanded(
                              child: pw.Text(
                                'Net total',
                                style: pw.TextStyle(
                                  fontWeight: pw.FontWeight.bold,
                                  color: color,
                                ),
                              ),
                            ),
                            pw.Text(
                              '₦ ${formatNaira(netTotal)}',
                              style: pw.TextStyle(
                                fontWeight: pw.FontWeight.bold,
                                color: color,
                              ),
                            ),
                          ],
                        ),
                        if (discount)
                          pw.Row(
                            children: [
                              pw.Expanded(
                                child: pw.Text(
                                  'Discount (${discountPercent.toStringAsFixed(0)}%)',
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    color: PdfColors.red700,
                                  ),
                                ),
                              ),
                              pw.Text(
                                '- ₦ ${formatNaira(discountAmount)}',
                                style: pw.TextStyle(
                                  fontWeight: pw.FontWeight.bold,
                                  color: PdfColors.red700,
                                ),
                              ),
                            ],
                          ),
                        pw.Row(
                          children: [
                            pw.Expanded(
                              child: pw.Text(
                                'VAT',
                                style: pw.TextStyle(
                                  fontWeight: pw.FontWeight.bold,
                                  color: color,
                                ),
                              ),
                            ),
                            pw.Text(
                              '₦ ${formatNaira(vat)}',
                              style: pw.TextStyle(
                                fontWeight: pw.FontWeight.bold,
                                color: color,
                              ),
                            ),
                          ],
                        ),
                        pw.Divider(),
                        pw.Row(
                          children: [
                            pw.Expanded(
                              child: pw.Text(
                                'Total amount due',
                                style: pw.TextStyle(
                                  fontSize: 14,
                                  fontWeight: pw.FontWeight.bold,
                                  color: color,
                                ),
                              ),
                            ),
                            pw.Text(
                              '₦ ${formatNaira(amountDue)}',
                              style: pw.TextStyle(
                                fontWeight: pw.FontWeight.bold,
                                color: color,
                              ),
                            ),
                          ],
                        ),
                        pw.SizedBox(height: 2 * PdfPageFormat.mm),
                        pw.Container(height: 1, color: PdfColors.grey400),
                        pw.SizedBox(height: 0.5 * PdfPageFormat.mm),
                        pw.Container(height: 1, color: PdfColors.grey400),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ];
        },
        footer: (context) {
          return pw.Column(
            mainAxisSize: pw.MainAxisSize.min,
            children: [
              pw.Divider(),
              pw.SizedBox(height: 2 * PdfPageFormat.mm),
              pw.Text(
                'Al-Amaz Shop',
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  color: color,
                ),
              ),
              pw.SizedBox(height: 1 * PdfPageFormat.mm),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'Address: ',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      color: color,
                    ),
                  ),
                  pw.Text(
                    'Zakirai kofar fada, opposite the central mosque',
                    style: pw.TextStyle(color: color),
                  ),
                ],
              ),
              pw.SizedBox(height: 1 * PdfPageFormat.mm),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'Email: ',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      color: color,
                    ),
                  ),
                  pw.Text(
                    'haiztech37@gmail.com',
                    style: pw.TextStyle(color: color),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );

    return pdf;
  }

  /// Builds + downloads the invoice.
  static Future<void> generate({
    required PdfColor color,
    required List<InvoiceLine> items,
    bool discount = false,
    double discountPercent = 20,
  }) async {
    final pdf = await buildDocument(
      color: color,
      items: items,
      discount: discount,
      discountPercent: discountPercent,
    );
    await FileHandleApi.saveDocument(name: 'my_invoice.pdf', pdf: pdf);
  }
}