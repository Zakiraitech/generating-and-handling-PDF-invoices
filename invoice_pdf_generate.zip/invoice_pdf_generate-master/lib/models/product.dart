class Product {
  final String name;
  final double price;

  const Product({required this.name, required this.price});
}

String formatNaira(num value) {
  final bool isInt = value == value.truncateToDouble();
  final String raw = isInt ? value.toInt().toString() : value.toStringAsFixed(2);
  final int dot = raw.indexOf('.');
  final String whole = dot == -1 ? raw : raw.substring(0, dot);
  final String frac = dot == -1 ? '' : raw.substring(dot);

  final StringBuffer buf = StringBuffer();
  for (int i = 0; i < whole.length; i++) {
    if (i > 0 && (whole.length - i) % 3 == 0) buf.write(',');
    buf.write(whole[i]);
  }
  return '$buf$frac';
}