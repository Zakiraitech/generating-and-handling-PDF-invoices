import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';

import 'data/products.dart';
import 'file_handle_api.dart';
import 'models/product.dart';
import 'pdf_invoice_api.dart';

void main() => runApp(const MainApp());

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Invoice PDF Generate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  PdfColor themeColor = PdfColors.black;
  final Map<Product, int> _selected = {};
  String _query = '';
  bool _discountEnabled = false;
  static const double _discountPercent = 20;

  double get _rawTotal =>
      _selected.entries.fold(0, (s, e) => s + e.key.price * e.value);

  double get _discountAmount =>
      _discountEnabled ? _rawTotal * (_discountPercent / 100) : 0;

  double get _total => _rawTotal - _discountAmount;

  int get _itemCount => _selected.values.fold(0, (s, q) => s + q);

  List<Product> get _filtered {
    if (_query.trim().isEmpty) return kProducts;
    final q = _query.toLowerCase();
    return kProducts.where((p) => p.name.toLowerCase().contains(q)).toList();
  }

  void _toggle(Product p, bool selected) {
    setState(() {
      if (selected) {
        _selected[p] = 1;
      } else {
        _selected.remove(p);
      }
    });
  }

  void _increment(Product p) =>
      setState(() => _selected[p] = (_selected[p] ?? 1) + 1);

  void _decrement(Product p) {
    setState(() {
      final q = _selected[p] ?? 1;
      if (q <= 1) {
        _selected.remove(p);
      } else {
        _selected[p] = q - 1;
      }
    });
  }

  List<InvoiceLine> _buildLines() => _selected.entries
      .map((e) => InvoiceLine(
    description: e.key.name,
    quantity: e.value,
    unitPrice: e.key.price,
  ))
      .toList();

  Future<void> _generateInvoice() async {
    if (_selected.isEmpty) return;
    try {
      await PdfInvoiceApi.generate(
        color: themeColor,
        items: _buildLines(),
        discount: _discountEnabled,
        discountPercent: _discountPercent,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice generated successfully!')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error generating invoice: $e')),
      );
    }
  }

  Future<void> _shareInvoice() async {
    if (_selected.isEmpty) return;
    try {
      final pdf = await PdfInvoiceApi.buildDocument(
        color: themeColor,
        items: _buildLines(),
        discount: _discountEnabled,
        discountPercent: _discountPercent,
      );
      await FileHandleApi.shareDocument(name: 'my_invoice.pdf', pdf: pdf);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error sharing invoice: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Build Invoice'),
        actions: [
          IconButton(
            tooltip: _discountEnabled
                ? 'Discount ON (20% off) — tap to remove'
                : 'Apply 20% discount',
            icon: Icon(
              _discountEnabled ? Icons.percent : Icons.percent_outlined,
              color: _discountEnabled ? Colors.amberAccent : null,
            ),
            onPressed: () =>
                setState(() => _discountEnabled = !_discountEnabled),
          ),
          IconButton(
            tooltip: 'Share invoice',
            icon: const Icon(Icons.share),
            onPressed: _selected.isEmpty ? null : _shareInvoice,
          ),
          PopupMenuButton<PdfColor>(
            icon: const Icon(Icons.palette),
            tooltip: 'Theme color',
            onSelected: (c) => setState(() => themeColor = c),
            itemBuilder: (_) => const [
              PopupMenuItem(value: PdfColors.black, child: Text('Black')),
              PopupMenuItem(value: PdfColors.blue, child: Text('Blue')),
              PopupMenuItem(value: PdfColors.green, child: Text('Green')),
              PopupMenuItem(
                value: PdfColors.grey900,
                child: Text('Dark Grey'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // ── Search bar ──────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search products…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _query.isEmpty
                    ? null
                    : IconButton(
                  icon: const Icon(Icons.clear),
                  tooltip: 'Clear search',
                  onPressed: () => setState(() => _query = ''),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                isDense: true,
              ),
            ),
          ),

          // ── Discount banner ────────────────────────────
          if (_discountEnabled)
            Container(
              width: double.infinity,
              color: Colors.amber.shade100,
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              child: Row(
                children: [
                  const Icon(Icons.local_offer, size: 18),
                  const SizedBox(width: 8),
                  const Text(
                    '20% discount applied',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  Text(
                    'Total: ₦ ${formatNaira(_total)}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),

          // ── Product list ───────────────────────────────
          Expanded(
            child: filtered.isEmpty
                ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No products match your search.',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            )
                : ListView.separated(
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final p = filtered[i];
                final qty = _selected[p];
                final isSelected = qty != null;

                return CheckboxListTile(
                  value: isSelected,
                  onChanged: (v) => _toggle(p, v ?? false),
                  title: Text(p.name),
                  subtitle: Text('₦ ${formatNaira(p.price)}'),
                  controlAffinity: ListTileControlAffinity.leading,
                  secondary: isSelected
                      ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.remove_circle_outline,
                        ),
                        onPressed: () => _decrement(p),
                      ),
                      Text(
                        '$qty',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.add_circle_outline,
                        ),
                        onPressed: () => _increment(p),
                      ),
                    ],
                  )
                      : null,
                );
              },
            ),
          ),

          // ── Bottom bar ─────────────────────────────────
          _BottomBar(
            itemCount: _itemCount,
            rawTotal: _rawTotal,
            discountAmount: _discountAmount,
            total: _total,
            onGenerate: _selected.isEmpty ? null : _generateInvoice,
            onShare: _selected.isEmpty ? null : _shareInvoice,
          ),
        ],
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final int itemCount;
  final double rawTotal;
  final double discountAmount;
  final double total;
  final VoidCallback? onGenerate;
  final VoidCallback? onShare;

  const _BottomBar({
    required this.itemCount,
    required this.rawTotal,
    required this.discountAmount,
    required this.total,
    required this.onGenerate,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 8,
      color: Theme.of(context).cardColor,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Items: $itemCount',
                    style: const TextStyle(fontSize: 16),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (discountAmount > 0)
                        Text(
                          '₦ ${formatNaira(rawTotal)}',
                          style: const TextStyle(
                            fontSize: 13,
                            decoration: TextDecoration.lineThrough,
                            color: Colors.grey,
                          ),
                        ),
                      Text(
                        'Total: ₦ ${formatNaira(total)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 50,
                      child: OutlinedButton.icon(
                        onPressed: onShare,
                        icon: const Icon(Icons.share),
                        label: const Text(
                          'Share',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: SizedBox(
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: onGenerate,
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text(
                          'Generate Invoice',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}