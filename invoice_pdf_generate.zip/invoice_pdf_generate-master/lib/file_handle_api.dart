import 'dart:js_interop';
import 'dart:typed_data';

import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:web/web.dart' as web;

class FileHandleApi {
  static Future<void> saveDocument({
    required String name,
    required pw.Document pdf,
  }) async {
    final Uint8List bytes = await pdf.save();
    _downloadBytes(bytes, name);
  }

  static Future<void> shareDocument({
    required String name,
    required pw.Document pdf,
  }) async {
    final Uint8List bytes = await pdf.save();
    try {
      await Share.shareXFiles(
        [
          XFile.fromData(bytes, mimeType: 'application/pdf', name: name),
        ],
        subject: 'Invoice',
        text: 'Please find your invoice attached.',
      );
    } catch (_) {
      _downloadBytes(bytes, name);
    }
  }

  static void _downloadBytes(Uint8List bytes, String name) {
    final blob = web.Blob(
      [bytes.toJS].toJS as JSArray<web.BlobPart>,
      web.BlobPropertyBag(type: 'application/pdf'),
    );
    final url = web.URL.createObjectURL(blob);
    final anchor = web.HTMLAnchorElement()
      ..href = url
      ..download = name;
    anchor.click();
    web.URL.revokeObjectURL(url);
  }
}